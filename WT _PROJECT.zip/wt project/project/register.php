<?php
require "database.php";
/*if($connection)
{
    echo "connection established";
}
else{
    echo "ERROR:".mysqli_error($connection);

}*/

$name=$_POST["name"];
$email=$_POST["email"];
$ph=$_POST["phoneNumber"];
/*$gen=$_POST["gender"];
$dis=$_post["diseases"];
$add=$_post["about"];*/
$query="CREATE TABLE register(name VARCHAR(10),email VARCHAR(25) NOT NULL, phone INT)";

if(mysqli_query($connection,$query))
{
    //echo "table created";

}
else{
    //echo "Error:".$query.mysqli_error($connection);
}

//inserting values into table
$query="INSERT INTO register VALUES('$name','$email','$ph');";

if(mysqli_query($connection,$query))
{
    //echo "record inserted"."<br>";

}
else{
   // echo "Error:".$query.mysqli_error($connection)."<br>";
}
$query="SELECT * FROM register;";
$check=mysqli_query($connection,$query);
/*if(mysqli_num_rows($check))
{
    while($row = mysqli_fetch_assoc($check))
    echo $row['username']." ".$row['email']." ".$row['password']."<br>";

}*/

?>
