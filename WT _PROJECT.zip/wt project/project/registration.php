<!DOCTYPE html>
<html>
<head>
<title>RESTRATION FORM</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="X-UA-Compatible" content="ie=edge" />
<link rel="stylesheet" href="register.css"/>
</head>
<style>
body{
background-image:
url("vvv.gif");
}
</style>
<body>
<div class="container">
  <h1>FORM FOR REGISTRATION</h1>
  <form action="register.php" name="registration" class="registartion-form" onsubmit="return formValidation()" method="POST">
    <table>
      <tr>
        <td><label for="name">Name:</label></td>
        <td><input type="text" name="name" id="name" placeholder="your name"></td>
      </tr>
      <tr>
        <td><label for="email">Email:</label></td>
        <td><input type="text" name="email" id="email" placeholder="your email"></td>
      </tr>
      <tr>
        <td><label for="phoneNumber">Phone Number:</label></td>
        <td><input type="tel" name="phoneNumber" id="phoneNumber"></td>
      </tr>
      <tr>
        <td><label for="gender">Gender:</label></td>
        <td>Male: <input type="radio" name="gender" value="male">
          Female: <input type="radio" name="gender" value="female">
          Other: <input type="radio" name="gender" value="other"></td>
      </tr>
      <tr>
        <td><label for="diseases">Diseases</label></td>
        <td>
          <select name="diseases" id="diseases">
            <option value="on">Select Disease</option>
            <option value="on">Skin Problems</option>
            <option value="on">Diabetes</option>
            <option value="on">Commom illness</option>
            <option value="on"> Heart Diseases</option>
            <option value="on">Cancer</option>
          </select>
        </td>
      </tr>
	<tr>
        <td><label for="about">ADDRESS:</label></td>
        <td><textarea name="about" id="about" cols="25" rows="5" placeholder="enter your address"></textarea></td>
      </tr>
      <tr>
        <td colspan="2"><input type="submit" class="submit" value="Register" /></td>
      </tr>
    </table>
  </form>
</div>
</body>
</html>
<script>
const name = document.getElementById("name");
const email = document.getElementById("email");
const phoneNumber = document.getElementById("phoneNumber");
const gender = document.registration;
const Diseases = document.getElementById("diseases");

// function for form varification
function formValidation() {
  
  // checking name length
  if (name.value.length < 2 || name.value.length > 20) {
    alert("Name length should be more than 2 and less than 21");
    name.focus();
    return false;
  }
  // checking email
  if (email.value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {
    alert("Please enter a valid email!");
    email.focus();
    return false;
  }
  // checking phone number
  if (!phoneNumber.value.match(/^[1-9][0-9]{9}$/)) {
    alert("Phone number must be 10 characters long number and first digit can't be 0!");
    phoneNumber.focus();
    return false;
  }
  // checking gender
  if (gender.gender.value === "") {
    alert("Please select your gender!");
    return false;
  }
  // checking language
  if (Diseases.value === "") {
    alert("Please select the disease")
    return false;
  }
  return true;
}
</script>

