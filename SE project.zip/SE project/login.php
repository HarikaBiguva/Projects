<?php
include "database.php";
$name=mysqli_real_escape_string($connection,$_POST['loginUser']);
$phone=mysqli_real_escape_string($connection,$_POST['loginnumber']);
if($connection)
{
	echo "connection established";
}
/*$query="CREATE TABLE REGISTER(NAME VARCHAR(30) NOT NULL,PHONE VARCHAR(15) NOT NULL);";
if(mysqli_query($connection,$query))
{
	echo "table created";
}
else
{
	echo "error:".mysqli_error($connection);
}*/
$query1="INSERT INTO REGISTER VALUES('$name','$phone');";
if(mysqli_query($connection,$query1))
{
	echo "record inserted"."<br>";
}
else
{
	echo "error:".mysqli_error($connection);
}
$query2="SELECT * FROM REGISTER;";
$check=mysqli_query($connection,$query2);
if(mysqli_num_rows($check))
{
	while($row=mysqli_fetch_assoc($check))
	{
		echo $row['NAME']."  ".$row['PHONE']."<br>";
	}
}
header("Location:Main.html");

