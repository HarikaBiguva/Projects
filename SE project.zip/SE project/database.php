<?php
$connection=mysqli_connect("localhost","root","ramya2003","se");
?>
